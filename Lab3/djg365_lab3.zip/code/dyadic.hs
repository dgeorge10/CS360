{-# OPTIONS_GHC -fwarn-tabs #-}

module Dyadic where

dyadic = [2^k | k <- [0..]]
